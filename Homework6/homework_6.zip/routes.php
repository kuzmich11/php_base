<?php

return [
    'home' => 'controller/HomeController.php',
    'security' => 'controller/SecurityController.php',
    'tasks' => 'controller/TasksController.php',
];